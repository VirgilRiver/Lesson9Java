import java.awt.Color;

public interface Class2D extends Paint{
	   public void fill(Color color);	//Chuc nang to mau cho doi tuong 2D
	}